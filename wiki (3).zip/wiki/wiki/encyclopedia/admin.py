from django.contrib import admin
from .models import create_new_page

# Register your models here.
admin.site.register(create_new_page)

