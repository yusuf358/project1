import random
from . import util 


value = random.choice("entries")
print(random.choice("entries"))
