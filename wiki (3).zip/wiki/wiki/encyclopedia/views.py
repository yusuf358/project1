import random
from django.shortcuts import render, get_object_or_404
from django import forms
from django.http import HttpResponseRedirect
from django.urls import reverse
from django.views.generic import ListView, DetailView
from django.views.generic.edit import CreateView 
from . import util
from .models import create_new_page 
from . import random
from django.db import models
from django.core.files.storage import default_storage 

def index(request):
    if request.method == "GET":
        return render(request, "encyclopedia/index.html", {
        "entries": util.list_entries(), "form": SearchForm()})
    # some trial and error
    if "entries" not in util.list_entries():
            util.list_entries()["entries"] = []
    return render(request, "encyclopedia/index.html", {
        "entries": util.list_entries()
    })
    def posts(request, name):
        return render(request, "encyclopedia/index.html", { "name": name.capitalize()})
    
class title(object):
        title = models.CharField(max_length=20)

class content(object):
        contents = models.CharField(max_length=200)

def create_new_page_detail(request, pk):
    template = "newpage.html"

    create_new_page = get_object_or_404(Post, pk=pk)
    context = {
        'newpage': newpage,
        }
    return render(request, template, context)
#end

# importent working code :)
class NewPageForm(forms.Form):
    titles = forms.CharField(label="", widget=forms.TextInput(attrs={ 'placeholder': 'Put Title Here', 'id': 'new_title'}))
    contents = forms.CharField(label="", widget=forms.Textarea(attrs={ 'id': 'new_entry'}))

class EditPageForm(forms.Form):
      titles = forms.CharField(label="", widget=forms.TextInput(attrs={ 'id': 'edit_title'}))
      contents = forms.CharField(label="", widget=forms.Textarea(attrs={ 'id': 'edit_entry'}))

class SearchForm(forms.Form):
    query = forms.CharField(label="", widget=forms.TextInput(attrs={'placeholder': 'Search Encyclopedia entrys', 'style': 'width:100%'}))
# end 



def newpage(request):
    if request.method == "GET":
        return render(request, "encyclopedia/newpage.html", {"form": NewPageForm()})
    # more trial and error
    else:
        new_entry = NewPageForm(request.POST)
        if new_entry.is_valid():
            titles = new_entry.cleaned_data["titles"]
            contents = new_entry.cleaned_data["data"]
            entries_all =  util.list_entries()
            for entry in entries_all:
                if entry.lower() == title.lower():
                    return render(request, "encyclopedia/newpage.html", { "form": SearchForm(), "NewPageForm": "NewPageForm()", "error": "an entry with that name already exists:( "})
                new_title = " # " + titles
                new_contents = "/n" + contents
                new_entry = new_title + new_contents
                util.save_entry(titles, new_entry)
                entry = util.get_entry(titles)
                return render(request, "encyclopedia/entry.html", { "titles": titles, "entry": markdown2.markdown(entry), "form": SearchForm() 
                 })
def editEntry(request, titles):
                if request.method == "POST":
                    entry = util.get_entry(titles)
                    Edit_Form = EditPageForm(initial= { 'titles': titles, 'contents': entry})
                    return render(request, "encyclopedia/edit.html", { "form": SearchForm(), "EditPageForm": Edit_Form, "entry": entry, "titles": titles})
# old code :(
   #         util.list_entries()["entries"] += [titles]
    #        return HttpResponseRedirect(reverse("encyclopedia:index"))
     #   titles = util.list_entries()
      #  try:
       #  contents = request.POST["contents"]
        #except KeyError:
         #contents = "Guest"
        #title = request.POST.get["title", "guest()"]
        #if title in titles:
         #   return ("entry already exists")
          #  return ("Please Try A Different One")
           # save_entry(title, content)
            #return render(request, "encyclopedia/index.html", {"title": markdown2.markdown(util.get_entry(content))})
    #class title(object):
     #   title = models.CharField(max_length=20)
     #
    #class content(object):
     #   contents = models.CharField(max_length=200)

def RandomListView(request):
    entries = util.list_entries()
    titles = random.choice(entries)
    entry = util.get_entry(titles)
    return HttpResponseRedirect(reverse("entry", args=[titles]))
#    if request.method == "GET":
#        return render(request, "encyclopedia/index.html")
#    random = random.choice("entries")
#    print(random.choice("entries"))
#
#def posts(request, name):
#   return render(request, "encyclopedia/index.html", { "name": name.capitalize()})
#end

# working important code :)
def entry(request, title):
    entry = util.get_entry(title)
    if entry is None:
        return render(request, "encyclopedia/opps_error.html", { "title": title, "form": SearchForm()
        })
    else:
        return render(request, "encyclopedia/entry.html", {
            "title": title,
            "entry": markdown2.markdown(entry),
            "entry_raw": entry,
            "form": SearchForm()
        })

def search(request):
    if request.method == "POST":
        entries_found = []  
        entries_all = util.list_entries()  
        form = SearchForm(request.POST)  
        if form.is_valid():
            query = form.cleaned_data["query"]
            for entry in entries_all:
                if query.lower() == entry.lower():
                    title = entry
                    entry = util.get_entry(title)
                    return HttpResponseRedirect(reverse("entry", args=[title]))
                if query.lower() in entry.lower():
                    entries_found.append(entry)
            return render(request, "encyclopedia/search.html", {
                "results": entries_found,
                "query": query,
                "form": SearchForm()
            })
        return render(request, "encyclopedia/search.html", {
        "results": "",
        "query": "",
        "form": SearchForm()
    })
def submitEditEntry(request, titles):
    if request.method == "POST":        
        edit_entry = EditPageForm(request.POST)
        if edit_entry.is_valid():            
            content = edit_entry.cleaned_data["contents"]           
            title_edit = edit_entry.cleaned_data["titles"]           
            if title_edit != titles:
                filename = f"entries/{titles}.md"
                if default_storage.exists(filename):
                    default_storage.delete(filename)          
            util.save_entry(title_edit, contents)            
            entry = util.get_entry(title_edit)
            msg_success = "Successfully updated!"      
        return render(request, "encyclopedia/entry.html", {
            "titles": title_edit,
            "entry": markdown2.markdown(entry),
            "form": SearchForm(),
            "msg_success": msg_success
        })
    #end
