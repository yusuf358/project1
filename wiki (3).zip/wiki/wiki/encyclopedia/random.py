import random
from . import util 

def random():
    random = random.choice("entries")
    print(random.choice("entries"))
