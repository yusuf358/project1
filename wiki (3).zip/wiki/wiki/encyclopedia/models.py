from django.db import models

# Create your models here.
class create_new_page(models.Model):
    title = models.CharField(max_length=20)
    contents = models.TextField()

class user(models.Model):
    Full_name = models.CharField(max_length=70)

    def __str__(self):
      return self.Full_name